<template>
  <div>
  </div>
</template>

<script>
export default {
  name: 'OptionListItem',
  props: {
    option: Object,
  },
  methods: {
    increase() {
    },
    decrease() {
    },
  },
}
</script>

<style>
</style>